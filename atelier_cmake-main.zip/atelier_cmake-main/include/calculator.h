double _add(double a, double b);
double _sub(double a, double b);
double _mul(double a, double b);
double _div(double a, double b);